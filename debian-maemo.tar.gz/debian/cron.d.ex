#
# Regular cron jobs for the groove package
#
0 4	* * *	root	groove_maintenance
