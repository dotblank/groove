?package(groove):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="groove" command="/usr/bin/groove"
